function imagescc(currentImg)
imagesc(currentImg);colormap(gray);axis image;axis off;