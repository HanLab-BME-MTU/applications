colormap_original = colormap;
colormap_flipped = flipud(colormap_original);
colormap(colormap_flipped);