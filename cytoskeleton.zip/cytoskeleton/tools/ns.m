function ns(im)
figure;imagesc(im);
axis image;
axis off;
colormap(gray);